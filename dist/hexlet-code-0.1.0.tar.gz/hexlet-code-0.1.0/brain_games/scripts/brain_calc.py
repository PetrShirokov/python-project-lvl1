#!/usr/bin/env python
from brain_games.games_body import play_game


def main():
    game_name = 'calc'
    play_game(game_name)


if __name__ == "__main__":
    main()
