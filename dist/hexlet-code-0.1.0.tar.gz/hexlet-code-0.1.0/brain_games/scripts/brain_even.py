#!/usr/bin/env python

from brain_games import even


def main():
    even.welcome_user()
    even.even_main()


if __name__ == '__main__':
    main()
