def is_even(number):
    """Returns 'yes' if number is even, else 'no'."""
    answer = 'yes' if (number % 2) == 0 else 'no'
    return answer
